# Nova Streetwear — AP3 JavaScript Avanzado

Aplicación web e-commerce desarrollada con **React**, **React Router DOM**, **Tailwind CSS** y **JSON Server**.

---

## Tecnologías
- React 18 + Vite
- React Router DOM v6
- Tailwind CSS v4
- JSON Server (Fetch API)
- JavaScript ES6+

---

## Instalación y uso

```bash
# 1. Instalar dependencias
npm install

# 2. Terminal A — JSON Server
npx json-server db.json --port 3000

# 3. Terminal B — React
npm run dev
```

Abrir: `http://localhost:5173`

---

## Estructura del proyecto

```
src/
├── assets/          # Recursos estáticos
├── components/      # Componentes reutilizables
│   ├── Navbar.jsx
│   ├── Footer.jsx
│   ├── ProductCard.jsx
│   ├── Spinner.jsx
│   ├── AlertaError.jsx
│   └── SectionHeader.jsx
├── pages/           # Páginas de la app
│   ├── Home.jsx
│   ├── Nosotros.jsx
│   ├── Productos.jsx
│   ├── Ofertas.jsx
│   ├── Contacto.jsx
│   └── NotFound.jsx
├── services/        # Lógica de consumo REST
│   └── productoService.js
├── App.jsx
├── main.jsx
└── index.css
```

---

## Páginas

| Ruta | Página |
|------|--------|
| `/` | Inicio (Home) |
| `/nosotros` | Presentación / Nosotros |
| `/productos` | Catálogo con buscador y filtros |
| `/ofertas` | Productos en descuento |
| `/contacto` | Formulario de contacto |
| `/*` | 404 personalizada |

---

## Requisitos AP3 cumplidos

- ✅ React + Vite
- ✅ React Router DOM con rutas y 404
- ✅ Tailwind CSS en todos los componentes
- ✅ JSON Server con db.json
- ✅ Fetch API en `services/productoService.js`
- ✅ Componentes funcionales
- ✅ Props en todos los componentes reutilizables
- ✅ useState (formularios, carrito, filtros, estados)
- ✅ useEffect (consumo REST al montar)
- ✅ Renderizado dinámico con map()
- ✅ Renderizado condicional
- ✅ Manejo de eventos
- ✅ Formulario con validaciones básicas
- ✅ Diseño responsive desktop y mobile
- ✅ Carpetas: pages/, components/, services/, assets/
