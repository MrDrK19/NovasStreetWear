// ─────────────────────────────────────────
//  Services/productoService.js
//  Consumo REST con Fetch API
// ─────────────────────────────────────────

const BASE_URL = 'http://localhost:3000';

/** Obtiene todos los productos */
export async function getProductos() {
  const res = await fetch(`${BASE_URL}/productos`);
  if (!res.ok) throw new Error('Error al obtener productos');
  return res.json();
}

/** Obtiene solo los productos en oferta */
export async function getOfertas() {
  const res = await fetch(`${BASE_URL}/productos?oferta=true`);
  if (!res.ok) throw new Error('Error al obtener ofertas');
  return res.json();
}

/** Obtiene un producto por id */
export async function getProductoById(id) {
  const res = await fetch(`${BASE_URL}/productos/${id}`);
  if (!res.ok) throw new Error('Producto no encontrado');
  return res.json();
}

/** Envía un mensaje de contacto (POST) */
export async function enviarContacto(datos) {
  const res = await fetch(`${BASE_URL}/contactos`, {
    method:  'POST',
    headers: { 'Content-Type': 'application/json' },
    body:    JSON.stringify({ ...datos, fecha: new Date().toISOString() }),
  });
  if (!res.ok) throw new Error('Error al enviar mensaje');
  return res.json();
}
