import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import ProductCard   from '../components/ProductCard';
import Spinner       from '../components/Spinner';
import AlertaError   from '../components/AlertaError';
import SectionHeader from '../components/SectionHeader';
import { getProductos } from '../services/productoService';

const FEATURES = [
  { icono:'👕', titulo:'Nuevas Colecciones', desc:'Estilos únicos diseñados para quienes se atreven a destacar en las calles de Lima.' },
  { icono:'⭐', titulo:'Estilismo Personal',  desc:'Te ayudamos a crear el guardarropa perfecto. Combinaciones únicas para cada ocasión.' },
  { icono:'⚡', titulo:'Diseño Creativo',     desc:'Cada prenda nace de la creatividad y la búsqueda constante de lo más auténtico.' },
];

const STATS = [
  { valor:'8+',   label:'Productos'  },
  { valor:'4',    label:'Categorías' },
  { valor:'100%', label:'Streetwear' },
  { valor:'10%',  label:'Descuentos' },
];

export default function Home() {
  const [destacados,    setDestacados]    = useState([]);
  const [cargando,      setCargando]      = useState(true);
  const [error,         setError]         = useState(null);
  const [carrito,       setCarrito]       = useState([]);
  const [avisoCarrito,  setAvisoCarrito]  = useState('');

  useEffect(() => {
    getProductos()
      .then(data => { setDestacados(data.slice(0, 3)); setCargando(false); })
      .catch(e  => { setError(e.message); setCargando(false); });
  }, []);

  const agregarAlCarrito = (producto) => {
    setCarrito(prev => {
      const existe = prev.find(p => p.id === producto.id);
      if (existe) return prev.map(p => p.id === producto.id ? { ...p, cantidad: p.cantidad + 1 } : p);
      return [...prev, { ...producto, cantidad: 1 }];
    });
    setAvisoCarrito(`✅ "${producto.nombre}" agregado`);
    setTimeout(() => setAvisoCarrito(''), 2500);
  };

  const totalCarrito = carrito.reduce((a, p) => a + p.precio * p.cantidad, 0);

  return (
    <div style={{ background:'#0a0a0a' }}>

      {/* ══ HERO ══ */}
      <section style={{ minHeight:'100vh', display:'flex', alignItems:'center', paddingTop:'80px', position:'relative', overflow:'hidden' }}>
        {/* Texto decorativo de fondo */}
        <div style={{
          position:'absolute', top:'50%', left:'50%', transform:'translate(-50%,-50%)',
          fontFamily:'Bebas Neue,sans-serif', fontSize:'28vw', color:'rgba(255,255,255,0.03)',
          letterSpacing:'10px', whiteSpace:'nowrap', pointerEvents:'none', userSelect:'none',
        }}>NOVA</div>

        <div className="container">
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'60px', alignItems:'center' }} className="hero-grid">

            {/* Texto */}
            <div className="fade-in">
              <span style={{ display:'inline-block', background:'#e8c84a', color:'#0a0a0a', fontSize:'0.68rem', fontWeight:800, letterSpacing:'3px', textTransform:'uppercase', padding:'5px 14px', marginBottom:'20px' }}>
                Colección 2026
              </span>
              <h1 className="bebas" style={{ fontSize:'clamp(3.5rem,8vw,7rem)', lineHeight:0.95, letterSpacing:'4px', marginBottom:'20px' }}>
                STYLE<br/>THAT<br/><span style={{ color:'#e8c84a' }}>SPEAKS</span>
              </h1>
              <p style={{ color:'#888', fontWeight:300, maxWidth:'400px', lineHeight:1.75, marginBottom:'36px', fontSize:'0.95rem' }}>
                La ropa no significa nada hasta que alguien la usa. Encuentra el estilo que te define en Nova Streetwear.
              </p>
              <div style={{ display:'flex', gap:'14px', flexWrap:'wrap' }}>
                <Link to="/productos" className="btn-primary">Ver Colección</Link>
                <Link to="/nosotros"  className="btn-outline">Sobre Nosotros</Link>
              </div>
            </div>

            {/* Stats grid */}
            <div className="fade-in" style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'12px', maxWidth:'340px', margin:'0 auto' }}>
              {STATS.map((s, i) => (
                <div key={i} style={{
                  padding:'28px 16px', textAlign:'center',
                  background: i % 2 === 1 ? '#e8c84a' : '#1a1a1a',
                  border: `1px solid ${i % 2 === 1 ? '#e8c84a' : '#2e2e2e'}`,
                }}>
                  <strong className="bebas" style={{ display:'block', fontSize:'2.5rem', color: i % 2 === 1 ? '#0a0a0a' : '#f5f5f0' }}>
                    {s.valor}
                  </strong>
                  <span style={{ fontSize:'0.68rem', letterSpacing:'2px', textTransform:'uppercase', color: i % 2 === 1 ? '#333' : '#888' }}>
                    {s.label}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        <style>{`@media(max-width:768px){ .hero-grid{ grid-template-columns:1fr !important; gap:40px !important; } }`}</style>
      </section>

      {/* ══ FEATURES ══ */}
      <section style={{ padding:'100px 0', background:'#1a1a1a' }}>
        <div className="container">
          <SectionHeader label="Por qué Nova" titulo="NUESTROS VALORES" center />
          <div className="grid-3" style={{ marginTop:'40px' }}>
            {FEATURES.map((f, i) => (
              <div key={i} className="feature-card">
                <span style={{ fontSize:'2rem', display:'block', marginBottom:'16px' }}>{f.icono}</span>
                <h5 style={{ fontWeight:700, fontSize:'0.88rem', textTransform:'uppercase', letterSpacing:'1px', marginBottom:'10px' }}>{f.titulo}</h5>
                <p style={{ color:'#888', fontSize:'0.88rem', lineHeight:1.7, margin:0 }}>{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ══ PRODUCTOS DESTACADOS ══ */}
      <section style={{ padding:'100px 0', background:'#0a0a0a' }}>
        <div className="container">
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-end', marginBottom:'40px' }}>
            <SectionHeader label="Catálogo" titulo="DESTACADOS" />
            <Link to="/productos" className="btn-outline" style={{ padding:'10px 24px', whiteSpace:'nowrap' }}>Ver todos →</Link>
          </div>

          {avisoCarrito && (
            <div className="alert-success fade-in" style={{ marginBottom:'20px' }}>{avisoCarrito}</div>
          )}

          {cargando && <Spinner texto="Cargando productos..." />}
          {error    && <AlertaError mensaje={error} />}

          {!cargando && !error && (
            <div className="grid-3">
              {destacados.map(p => (
                <ProductCard key={p.id} producto={p} onAgregar={agregarAlCarrito} />
              ))}
            </div>
          )}

          {/* Mini carrito */}
          {carrito.length > 0 && (
            <div className="fade-in" style={{ marginTop:'32px', background:'#1a1a1a', border:'1px solid #2e2e2e', padding:'20px' }}>
              <h6 style={{ color:'#e8c84a', fontSize:'0.75rem', fontWeight:700, letterSpacing:'2px', textTransform:'uppercase', marginBottom:'12px' }}>
                Carrito — {carrito.reduce((a,p) => a+p.cantidad, 0)} items
              </h6>
              {carrito.map(p => (
                <div key={p.id} style={{ display:'flex', justifyContent:'space-between', fontSize:'0.85rem', color:'#888', padding:'6px 0', borderBottom:'1px solid #222' }}>
                  <span>{p.nombre} ×{p.cantidad}</span>
                  <span style={{ color:'#e8c84a' }}>S/ {(p.precio * p.cantidad).toFixed(0)}</span>
                </div>
              ))}
              <div style={{ display:'flex', justifyContent:'space-between', fontWeight:700, marginTop:'10px', fontSize:'0.9rem' }}>
                <span>Total</span>
                <span style={{ color:'#e8c84a' }}>S/ {totalCarrito.toFixed(0)}</span>
              </div>
            </div>
          )}
        </div>
      </section>

      {/* ══ CTA ══ */}
      <section style={{ padding:'100px 0', background:'#1a1a1a' }}>
        <div className="container" style={{ textAlign:'center' }}>
          <span className="section-label" style={{ justifyContent:'center', display:'block' }}>Únete</span>
          <h2 className="bebas section-title" style={{ marginBottom:'32px' }}>¿LISTO PARA DESTACAR?</h2>
          <div style={{ display:'flex', justifyContent:'center', gap:'16px', flexWrap:'wrap' }}>
            <Link to="/productos" className="btn-primary">Comprar Ahora</Link>
            <Link to="/contacto"  className="btn-outline">Contáctanos</Link>
          </div>
        </div>
      </section>

    </div>
  );
}
