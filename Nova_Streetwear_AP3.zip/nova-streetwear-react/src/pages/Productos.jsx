import { useState, useEffect } from 'react';
import ProductCard   from '../components/ProductCard';
import Spinner       from '../components/Spinner';
import AlertaError   from '../components/AlertaError';
import SectionHeader from '../components/SectionHeader';
import { getProductos } from '../services/productoService';

export default function Productos() {
  const [todos,     setTodos]     = useState([]);
  const [filtrados, setFiltrados] = useState([]);
  const [cats,      setCats]      = useState([]);
  const [busqueda,  setBusqueda]  = useState('');
  const [catActiva, setCatActiva] = useState('Todas');
  const [cargando,  setCargando]  = useState(true);
  const [error,     setError]     = useState(null);
  const [aviso,     setAviso]     = useState('');

  useEffect(() => {
    getProductos()
      .then(data => {
        setTodos(data); setFiltrados(data);
        setCats(['Todas', ...new Set(data.map(p => p.categoria))]);
        setCargando(false);
      })
      .catch(e => { setError(e.message); setCargando(false); });
  }, []);

  useEffect(() => {
    setFiltrados(todos.filter(p => {
      const matchN = p.nombre.toLowerCase().includes(busqueda.toLowerCase());
      const matchC = catActiva === 'Todas' || p.categoria === catActiva;
      return matchN && matchC;
    }));
  }, [busqueda, catActiva, todos]);

  const agregar = (p) => {
    setAviso(`✅ "${p.nombre}" agregado al carrito`);
    setTimeout(() => setAviso(''), 2000);
  };
  const limpiar = () => { setBusqueda(''); setCatActiva('Todas'); };

  return (
    <div style={{ paddingTop:'100px', paddingBottom:'80px', minHeight:'100vh', background:'#0a0a0a' }}>
      <div className="container">

        <SectionHeader label="Catálogo" titulo="NUESTROS PRODUCTOS"
          subtitulo="Explora toda nuestra colección de streetwear peruano." />

        {/* Filtros */}
        <div style={{ background:'#1a1a1a', border:'1px solid #222', padding:'20px 24px', marginBottom:'28px', display:'flex', flexDirection:'column', gap:'14px' }}>
          <input type="text" className="form-input" placeholder="Buscar producto..."
            value={busqueda} onChange={e => setBusqueda(e.target.value)}
            style={{ maxWidth:'360px' }} />
          <div style={{ display:'flex', flexWrap:'wrap', gap:'8px', alignItems:'center' }}>
            {cats.map(cat => (
              <button key={cat} onClick={() => setCatActiva(cat)}
                style={{
                  padding:'6px 16px', fontSize:'0.72rem', fontWeight:700,
                  letterSpacing:'1.5px', textTransform:'uppercase', cursor:'pointer',
                  border: catActiva === cat ? '1px solid #e8c84a' : '1px solid #333',
                  background: catActiva === cat ? '#e8c84a' : 'transparent',
                  color: catActiva === cat ? '#0a0a0a' : '#888',
                  transition:'all .15s',
                }}>
                {cat}
              </button>
            ))}
            {(busqueda || catActiva !== 'Todas') && (
              <button onClick={limpiar}
                style={{ padding:'6px 14px', fontSize:'0.72rem', border:'1px solid #e05555', color:'#e05555', background:'transparent', cursor:'pointer', transition:'all .2s' }}>
                ✕ Limpiar
              </button>
            )}
          </div>
        </div>

        {aviso && <div className="alert-success fade-in" style={{ marginBottom:'16px' }}>{aviso}</div>}
        {cargando && <Spinner />}
        {error    && <AlertaError mensaje={error} />}

        {!cargando && !error && (
          <>
            <p style={{ color:'#888', fontSize:'0.82rem', marginBottom:'20px' }}>
              Mostrando <strong style={{ color:'#f5f5f0' }}>{filtrados.length}</strong> de {todos.length} productos
            </p>
            <div className="grid-4">
              {filtrados.map(p => <ProductCard key={p.id} producto={p} onAgregar={agregar} />)}
            </div>
            {filtrados.length === 0 && (
              <div style={{ textAlign:'center', padding:'60px 0' }}>
                <p style={{ color:'#888', marginBottom:'20px' }}>Sin resultados para "{busqueda}"</p>
                <button onClick={limpiar} className="btn-primary">Limpiar búsqueda</button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
