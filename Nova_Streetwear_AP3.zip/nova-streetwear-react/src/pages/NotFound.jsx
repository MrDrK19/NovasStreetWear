import { Link } from 'react-router-dom';

export default function NotFound() {
  return (
    <div style={{ minHeight:'100vh', background:'#0a0a0a', display:'flex', alignItems:'center', justifyContent:'center', paddingTop:'80px' }}>
      <div className="fade-in" style={{ textAlign:'center', padding:'0 24px' }}>
        <div className="bebas" style={{ fontSize:'clamp(6rem,20vw,14rem)', color:'#e8c84a', lineHeight:1, letterSpacing:'10px', marginBottom:'10px' }}>
          404
        </div>
        <h2 className="bebas" style={{ fontSize:'2rem', letterSpacing:'3px', marginBottom:'16px' }}>PÁGINA NO ENCONTRADA</h2>
        <p style={{ color:'#888', marginBottom:'36px', maxWidth:'400px', margin:'0 auto 36px' }}>
          La ruta que buscas no existe o fue removida. Vuelve al inicio y sigue explorando.
        </p>
        <div style={{ display:'flex', justifyContent:'center', gap:'16px', flexWrap:'wrap' }}>
          <Link to="/"          className="btn-primary">← Volver al Inicio</Link>
          <Link to="/productos" className="btn-outline">Ver Productos</Link>
        </div>
      </div>
    </div>
  );
}
