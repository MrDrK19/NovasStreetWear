import { Link } from 'react-router-dom';
import SectionHeader from '../components/SectionHeader';

const VALORES = [
  { icono:'🎨', titulo:'Autenticidad', desc:'Cada diseño refleja la cultura urbana peruana sin filtros ni compromisos.' },
  { icono:'🌿', titulo:'Calidad',      desc:'Materiales seleccionados para durabilidad y comodidad real en el día a día.' },
  { icono:'🔥', titulo:'Tendencia',    desc:'Siempre un paso adelante en el streetwear latinoamericano.' },
  { icono:'🤝', titulo:'Comunidad',    desc:'Construimos identidad con cada persona que nos elige.' },
];

const EQUIPO = [
  { nombre:'César Edinson',   id:'U22325477', rol:'Frontend Developer',   inicial:'C' },
  { nombre:'Joaquín Jesús',   id:'U21228512', rol:'Full-Stack Developer',  inicial:'J' },
  { nombre:'Karlos',          id:'U22313805', rol:'Backend Developer',     inicial:'K' },
];

export default function Nosotros() {
  return (
    <div style={{ paddingTop:'100px', paddingBottom:'80px', minHeight:'100vh', background:'#0a0a0a' }}>
      <div className="container">

        <SectionHeader label="Sobre nosotros" titulo="QUIÉNES SOMOS"
          subtitulo="Nova Streetwear nació en Lima con una misión: llevar el streetwear auténtico a las calles peruanas." />

        {/* Historia + Valores */}
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'60px', marginBottom:'80px', alignItems:'start' }}
             className="about-grid">
          <div className="fade-in">
            <h3 className="bebas" style={{ fontSize:'2rem', letterSpacing:'2px', color:'#e8c84a', marginBottom:'16px' }}>NUESTRA HISTORIA</h3>
            <p style={{ color:'#888', lineHeight:1.8, marginBottom:'14px', fontSize:'0.9rem' }}>
              Fundada en 2023, Nova Streetwear comenzó como un proyecto universitario que se convirtió en
              una marca de identidad. Diseñamos prendas que hablan por sí solas: camisetas con referencias
              musicales, hoodies con corte urbano y accesorios que completan el look.
            </p>
            <p style={{ color:'#888', lineHeight:1.8, fontSize:'0.9rem' }}>
              Hoy contamos con una colección de más de 8 productos exclusivos en 4 categorías,
              diseñados y pensados para la nueva generación peruana que se atreve a destacar.
            </p>
          </div>
          <div className="grid-2 fade-in">
            {VALORES.map((v, i) => (
              <div key={i} style={{ background:'#1a1a1a', border:'1px solid #222', padding:'20px', transition:'border-color .2s' }}
                onMouseEnter={e => e.currentTarget.style.borderColor='#e8c84a'}
                onMouseLeave={e => e.currentTarget.style.borderColor='#222'}>
                <span style={{ fontSize:'1.5rem', display:'block', marginBottom:'10px' }}>{v.icono}</span>
                <h6 style={{ fontWeight:700, fontSize:'0.82rem', textTransform:'uppercase', letterSpacing:'1px', marginBottom:'6px' }}>{v.titulo}</h6>
                <p style={{ color:'#888', fontSize:'0.82rem', lineHeight:1.6, margin:0 }}>{v.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Equipo */}
        <div className="fade-in" style={{ marginBottom:'60px' }}>
          <SectionHeader label="El equipo" titulo="QUIÉNES LO HACEN POSIBLE" center />
          <div className="grid-3" style={{ marginTop:'32px' }}>
            {EQUIPO.map((m, i) => (
              <div key={i} style={{ background:'#1a1a1a', border:'1px solid #222', padding:'28px 20px', textAlign:'center', transition:'border-color .2s' }}
                onMouseEnter={e => e.currentTarget.style.borderColor='#e8c84a'}
                onMouseLeave={e => e.currentTarget.style.borderColor='#222'}>
                <div style={{ width:'56px', height:'56px', borderRadius:'50%', background:'#e8c84a', color:'#0a0a0a', fontFamily:'Bebas Neue,sans-serif', fontSize:'1.8rem', display:'flex', alignItems:'center', justifyContent:'center', margin:'0 auto 14px' }}>
                  {m.inicial}
                </div>
                <h6 style={{ fontWeight:700, fontSize:'0.88rem', marginBottom:'4px' }}>{m.nombre}</h6>
                <p style={{ color:'#e8c84a', fontSize:'0.72rem', letterSpacing:'1px', margin:'0 0 4px' }}>{m.id}</p>
                <p style={{ color:'#888', fontSize:'0.72rem', textTransform:'uppercase', letterSpacing:'1px', margin:0 }}>{m.rol}</p>
              </div>
            ))}
          </div>
        </div>

        <div style={{ textAlign:'center' }}>
          <Link to="/productos" className="btn-primary">Ver Nuestra Colección</Link>
        </div>
      </div>

      <style>{`@media(max-width:768px){ .about-grid{ grid-template-columns:1fr !important; gap:36px !important; } }`}</style>
    </div>
  );
}
