import { useState } from 'react';
import SectionHeader from '../components/SectionHeader';
import { enviarContacto } from '../services/productoService';

export default function Contacto() {
  const [form,     setForm]     = useState({ nombre:'', email:'', asunto:'', mensaje:'' });
  const [errores,  setErrores]  = useState({});
  const [enviando, setEnviando] = useState(false);
  const [exito,    setExito]    = useState(false);
  const [errorApi, setErrorApi] = useState('');

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value }));
    if (errores[name]) setErrores(prev => ({ ...prev, [name]: '' }));
  };

  const validar = () => {
    const e = {};
    if (!form.nombre.trim())  e.nombre  = 'El nombre es requerido.';
    if (!form.email.trim())   e.email   = 'El correo es requerido.';
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) e.email = 'Correo inválido.';
    if (!form.mensaje.trim()) e.mensaje = 'El mensaje es requerido.';
    else if (form.mensaje.trim().length < 10) e.mensaje = 'Mínimo 10 caracteres.';
    setErrores(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = async (ev) => {
    ev.preventDefault();
    if (!validar()) return;
    setEnviando(true); setErrorApi('');
    try {
      await enviarContacto(form);
      setExito(true);
      setForm({ nombre:'', email:'', asunto:'', mensaje:'' });
      setTimeout(() => setExito(false), 5000);
    } catch {
      setErrorApi('No se pudo enviar. Asegúrate de que JSON Server esté activo.');
    } finally { setEnviando(false); }
  };

  const INFO = [
    { icono:'📍', titulo:'Ubicación',  valor:'Lima, Perú' },
    { icono:'📧', titulo:'Email',      valor:'novastreetwear@gmail.com' },
    { icono:'💬', titulo:'WhatsApp',   valor:'Escríbenos directamente' },
    { icono:'🕐', titulo:'Horario',    valor:'Lun–Sáb: 10am – 8pm' },
  ];

  const inputStyle = (campo) => ({
    background:'#0a0a0a', border:`1px solid ${errores[campo] ? '#e05555' : '#333'}`,
    color:'#f5f5f0', padding:'10px 14px', fontSize:'0.9rem', outline:'none',
    width:'100%', fontFamily:'Barlow,sans-serif', transition:'border-color .2s',
  });

  return (
    <div style={{ paddingTop:'100px', paddingBottom:'80px', minHeight:'100vh', background:'#0a0a0a' }}>
      <div className="container">
        <SectionHeader label="Comunícate" titulo="CONTACTO"
          subtitulo="¿Tienes alguna consulta? Estamos para ayudarte." />

        <div style={{ display:'grid', gridTemplateColumns:'2fr 3fr', gap:'40px' }} className="contact-grid">

          {/* Info */}
          <div style={{ display:'flex', flexDirection:'column', gap:'14px' }}>
            {INFO.map((item, i) => (
              <div key={i} style={{ background:'#1a1a1a', border:'1px solid #222', padding:'20px', display:'flex', gap:'16px', alignItems:'flex-start', transition:'border-color .2s' }}
                onMouseEnter={e => e.currentTarget.style.borderColor='#e8c84a'}
                onMouseLeave={e => e.currentTarget.style.borderColor='#222'}>
                <span style={{ fontSize:'1.5rem' }}>{item.icono}</span>
                <div>
                  <strong style={{ display:'block', fontSize:'0.72rem', textTransform:'uppercase', letterSpacing:'1px', color:'#e8c84a', marginBottom:'4px' }}>{item.titulo}</strong>
                  <p style={{ color:'#888', fontSize:'0.88rem', margin:0 }}>{item.valor}</p>
                </div>
              </div>
            ))}
          </div>

          {/* Formulario */}
          <div style={{ background:'#1a1a1a', border:'1px solid #222', padding:'36px' }}>
            <h4 className="bebas" style={{ fontSize:'1.6rem', letterSpacing:'2px', marginBottom:'24px' }}>Envíanos un mensaje</h4>

            {exito    && <div className="alert-success"    style={{ marginBottom:'20px' }}>✅ ¡Mensaje enviado! Te responderemos pronto.</div>}
            {errorApi && <div className="alert-error-box" style={{ marginBottom:'20px' }}>⚠ {errorApi}</div>}

            <form onSubmit={handleSubmit} noValidate style={{ display:'flex', flexDirection:'column', gap:'18px' }}>

              {[['nombre','Nombre completo *','text','Tu nombre'], ['email','Correo electrónico *','text','correo@ejemplo.com']].map(([name, label, type, ph]) => (
                <div key={name}>
                  <label className="form-label">{label}</label>
                  <input type={type} name={name} value={form[name]} onChange={handleChange}
                    placeholder={ph} style={inputStyle(name)}
                    onFocus={e => { e.target.style.borderColor = errores[name] ? '#e05555' : '#e8c84a'; }}
                    onBlur={e  => { e.target.style.borderColor = errores[name] ? '#e05555' : '#333'; }} />
                  {errores[name] && <p className="form-error">{errores[name]}</p>}
                </div>
              ))}

              <div>
                <label className="form-label">Asunto</label>
                <input type="text" name="asunto" value={form.asunto} onChange={handleChange}
                  placeholder="¿En qué podemos ayudarte?" style={inputStyle('asunto')}
                  onFocus={e => e.target.style.borderColor='#e8c84a'}
                  onBlur={e  => e.target.style.borderColor='#333'} />
              </div>

              <div>
                <label className="form-label">Mensaje * <span style={{ color:'#555', fontSize:'0.7rem', textTransform:'none', letterSpacing:0, fontWeight:400 }}>(mín. 10 caracteres)</span></label>
                <textarea name="mensaje" value={form.mensaje} onChange={handleChange}
                  rows={5} placeholder="Escribe tu mensaje aquí..."
                  style={{ ...inputStyle('mensaje'), resize:'vertical' }}
                  onFocus={e => { e.target.style.borderColor = errores.mensaje ? '#e05555' : '#e8c84a'; }}
                  onBlur={e  => { e.target.style.borderColor = errores.mensaje ? '#e05555' : '#333'; }} />
                {errores.mensaje && <p className="form-error">{errores.mensaje}</p>}
              </div>

              <button type="submit" disabled={enviando}
                style={{ padding:'13px', background: enviando ? '#2e2e2e' : '#e8c84a', color: enviando ? '#555' : '#0a0a0a', fontWeight:800, fontSize:'0.82rem', letterSpacing:'2px', textTransform:'uppercase', border:'none', cursor: enviando ? 'not-allowed' : 'pointer', transition:'background .2s' }}
                onMouseEnter={e => { if (!enviando) e.target.style.background='#f0d84e'; }}
                onMouseLeave={e => { if (!enviando) e.target.style.background='#e8c84a'; }}>
                {enviando ? 'Enviando...' : 'Enviar Mensaje'}
              </button>
            </form>
          </div>
        </div>
      </div>
      <style>{`@media(max-width:768px){ .contact-grid{ grid-template-columns:1fr !important; } }`}</style>
    </div>
  );
}
