import { useState, useEffect } from 'react';
import Spinner     from '../components/Spinner';
import AlertaError from '../components/AlertaError';
import SectionHeader from '../components/SectionHeader';
import { getOfertas } from '../services/productoService';

export default function Ofertas() {
  const [ofertas,  setOfertas]  = useState([]);
  const [cargando, setCargando] = useState(true);
  const [error,    setError]    = useState(null);
  const [aviso,    setAviso]    = useState('');

  useEffect(() => {
    getOfertas()
      .then(data => { setOfertas(data); setCargando(false); })
      .catch(e  => { setError(e.message); setCargando(false); });
  }, []);

  const agregar = (nombre) => {
    setAviso(`✅ "${nombre}" agregado al carrito`);
    setTimeout(() => setAviso(''), 2500);
  };

  return (
    <div style={{ paddingTop:'100px', paddingBottom:'80px', minHeight:'100vh', background:'#0a0a0a' }}>
      <div className="container">
        <SectionHeader label="Descuentos exclusivos" titulo="OFERTAS ESPECIALES"
          subtitulo="Aprovecha nuestros descuentos por tiempo limitado. Stock reducido." />

        {aviso && <div className="alert-success fade-in" style={{ marginBottom:'20px' }}>{aviso}</div>}
        {cargando && <Spinner texto="Cargando ofertas..." />}
        {error    && <AlertaError mensaje={error} />}

        {!cargando && !error && (
          ofertas.length === 0
            ? <p style={{ color:'#888', textAlign:'center', padding:'60px 0' }}>No hay ofertas disponibles.</p>
            : <div className="grid-3">
                {ofertas.map(p => {
                  const final  = p.precio * (1 - p.descuento / 100);
                  const ahorro = p.precio - final;
                  return (
                    <div key={p.id} style={{ background:'#1a1a1a', border:'1px solid rgba(232,200,74,.3)', transition:'all .2s' }}
                      onMouseEnter={e => { e.currentTarget.style.borderColor='#e8c84a'; e.currentTarget.style.transform='translateY(-4px)'; }}
                      onMouseLeave={e => { e.currentTarget.style.borderColor='rgba(232,200,74,.3)'; e.currentTarget.style.transform='translateY(0)'; }}>
                      <div style={{ background:'#e8c84a', color:'#0a0a0a', fontWeight:800, fontSize:'0.72rem', letterSpacing:'2px', textTransform:'uppercase', padding:'8px', textAlign:'center' }}>
                        -{p.descuento}% DESCUENTO
                      </div>
                      <div style={{ background:'#111', height:'200px', overflow:'hidden' }}>
                        <img src={p.imagen} alt={p.nombre}
                          style={{ width:'100%', height:'100%', objectFit:'cover' }}
                          onError={e => { e.target.src='https://placehold.co/400x400/1a1a1a/e8c84a?text=NOVA'; }} />
                      </div>
                      <div style={{ padding:'20px' }}>
                        <span style={{ color:'#e8c84a', fontSize:'0.68rem', fontWeight:800, letterSpacing:'2px', textTransform:'uppercase' }}>{p.categoria}</span>
                        <h5 style={{ fontWeight:700, fontSize:'0.88rem', textTransform:'uppercase', margin:'6px 0 10px' }}>{p.nombre}</h5>
                        <div style={{ display:'flex', alignItems:'baseline', gap:'10px', marginBottom:'4px' }}>
                          <span style={{ fontSize:'0.88rem', color:'#555', textDecoration:'line-through' }}>S/ {p.precio}</span>
                          <span className="bebas" style={{ fontSize:'1.6rem', color:'#e8c84a' }}>S/ {final.toFixed(0)}</span>
                        </div>
                        <p style={{ color:'#50c878', fontSize:'0.78rem', marginBottom:'14px' }}>Ahorras S/ {ahorro.toFixed(0)}</p>
                        <button onClick={() => agregar(p.nombre)}
                          style={{ width:'100%', padding:'10px', background:'#e8c84a', color:'#0a0a0a', fontWeight:800, fontSize:'0.75rem', letterSpacing:'1.5px', textTransform:'uppercase', border:'none', cursor:'pointer' }}
                          onMouseEnter={e => e.target.style.background='#f0d84e'}
                          onMouseLeave={e => e.target.style.background='#e8c84a'}>
                          Aprovechar oferta
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
        )}
      </div>
    </div>
  );
}
