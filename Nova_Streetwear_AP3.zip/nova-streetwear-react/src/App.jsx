import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Navbar   from './components/Navbar';
import Footer   from './components/Footer';
import Home     from './pages/Home';
import Nosotros from './pages/Nosotros';
import Productos from './pages/Productos';
import Ofertas  from './pages/Ofertas';
import Contacto from './pages/Contacto';
import NotFound from './pages/NotFound';

export default function App() {
  return (
    <BrowserRouter>
      {/* Navbar reutilizable en todas las páginas */}
      <Navbar />

      <main>
        <Routes>
          <Route path="/"          element={<Home />} />
          <Route path="/nosotros"  element={<Nosotros />} />
          <Route path="/productos" element={<Productos />} />
          <Route path="/ofertas"   element={<Ofertas />} />
          <Route path="/contacto"  element={<Contacto />} />
          {/* Ruta 404 para cualquier path no definido */}
          <Route path="*"          element={<NotFound />} />
        </Routes>
      </main>

      {/* Footer reutilizable en todas las páginas */}
      <Footer />
    </BrowserRouter>
  );
}
