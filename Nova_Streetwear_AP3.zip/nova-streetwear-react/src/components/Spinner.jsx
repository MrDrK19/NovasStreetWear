export default function Spinner({ texto = 'Cargando...' }) {
  return (
    <div style={{ textAlign:'center', padding:'60px 0' }}>
      <div className="spinner" />
      <p style={{ color:'#888', fontSize:'0.85rem', marginTop:'12px' }}>{texto}</p>
    </div>
  );
}
