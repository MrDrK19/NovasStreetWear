import { useState } from 'react';
import { Link, NavLink } from 'react-router-dom';

export default function Navbar() {
  const [open, setOpen] = useState(false);

  const links = [
    { to: '/',          label: 'Inicio'    },
    { to: '/nosotros',  label: 'Nosotros'  },
    { to: '/productos', label: 'Productos' },
    { to: '/ofertas',   label: 'Ofertas'   },
    { to: '/contacto',  label: 'Contacto'  },
  ];

  return (
    <nav style={{
      position: 'fixed', top: 0, left: 0, right: 0, zIndex: 1000,
      background: 'rgba(10,10,10,0.97)',
      backdropFilter: 'blur(10px)',
      borderBottom: '1px solid #222',
    }}>
      <div className="container">
        <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding:'16px 0' }}>

          {/* Brand */}
          <Link to="/" style={{ fontFamily:'Bebas Neue,sans-serif', fontSize:'1.7rem', letterSpacing:'3px', color:'#f5f5f0', textDecoration:'none' }}>
            NOVA <span style={{ color:'#e8c84a' }}>STREETWEAR</span>
          </Link>

          {/* Desktop links */}
          <ul style={{ display:'flex', alignItems:'center', gap:'4px', listStyle:'none', margin:0, padding:0 }}
              className="nav-desktop">
            {links.map(l => (
              <li key={l.to}>
                <NavLink to={l.to} end={l.to === '/'}
                  style={({ isActive }) => ({
                    color: isActive ? '#e8c84a' : '#ccc',
                    textDecoration: 'none',
                    fontSize: '0.78rem',
                    fontWeight: 500,
                    letterSpacing: '1.5px',
                    textTransform: 'uppercase',
                    padding: '6px 10px',
                    transition: 'color .2s',
                  })}>
                  {l.label}
                </NavLink>
              </li>
            ))}
          </ul>

          {/* CTA */}
          <Link to="/productos" className="btn-primary nav-cta" style={{ padding:'8px 20px' }}>
            Ver Colección
          </Link>

          {/* Burger mobile */}
          <button onClick={() => setOpen(o => !o)}
            style={{ display:'none', flexDirection:'column', gap:'5px', background:'none', border:'none', cursor:'pointer', padding:'4px' }}
            className="burger-btn">
            {[0,1,2].map(i => (
              <span key={i} style={{ display:'block', width:'22px', height:'2px', background:'#f5f5f0', transition:'all .2s' }} />
            ))}
          </button>
        </div>

        {/* Mobile menu */}
        {open && (
          <div style={{ borderTop:'1px solid #222', paddingBottom:'16px' }} className="mobile-menu">
            {links.map(l => (
              <NavLink key={l.to} to={l.to} end={l.to === '/'} onClick={() => setOpen(false)}
                style={({ isActive }) => ({
                  display: 'block',
                  padding: '12px 4px',
                  color: isActive ? '#e8c84a' : '#ccc',
                  textDecoration: 'none',
                  fontSize: '0.85rem',
                  textTransform: 'uppercase',
                  letterSpacing: '1px',
                  borderBottom: '1px solid #1a1a1a',
                })}>
                {l.label}
              </NavLink>
            ))}
          </div>
        )}
      </div>

      <style>{`
        @media (max-width: 1024px) {
          .nav-desktop { display: none !important; }
          .nav-cta     { display: none !important; }
          .burger-btn  { display: flex !important; }
        }
      `}</style>
    </nav>
  );
}
