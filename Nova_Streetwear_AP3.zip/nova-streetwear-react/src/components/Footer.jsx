import { Link } from 'react-router-dom';

export default function Footer() {
  const anio = new Date().getFullYear();
  const cols = [
    ['/', 'Inicio'], ['/nosotros','Nosotros'], ['/productos','Productos'],
    ['/ofertas','Ofertas'], ['/contacto','Contacto'],
  ];
  return (
    <footer style={{ background:'#0a0a0a', borderTop:'1px solid #222', marginTop:'80px' }}>
      <div className="container">
        <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:'40px', padding:'60px 0 40px' }}
             className="footer-grid">
          <div>
            <div className="bebas" style={{ fontSize:'1.3rem', letterSpacing:'3px', marginBottom:'12px' }}>
              NOVA <span style={{ color:'#e8c84a' }}>STREETWEAR</span>
            </div>
            <p style={{ color:'#888', fontSize:'0.85rem', lineHeight:1.7 }}>
              La ropa no significa nada hasta que alguien la usa. Encuentra el estilo que te define.
            </p>
          </div>
          <div>
            <h6 style={{ color:'#e8c84a', fontSize:'0.68rem', letterSpacing:'3px', textTransform:'uppercase', fontWeight:700, marginBottom:'16px' }}>
              Navegación
            </h6>
            <ul style={{ listStyle:'none', padding:0, margin:0, display:'flex', flexDirection:'column', gap:'8px' }}>
              {cols.map(([to, label]) => (
                <li key={to}>
                  <Link to={to} style={{ color:'#888', textDecoration:'none', fontSize:'0.85rem', transition:'color .2s' }}
                    onMouseEnter={e => e.target.style.color='#e8c84a'}
                    onMouseLeave={e => e.target.style.color='#888'}>
                    {label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h6 style={{ color:'#e8c84a', fontSize:'0.68rem', letterSpacing:'3px', textTransform:'uppercase', fontWeight:700, marginBottom:'16px' }}>
              Contacto
            </h6>
            <ul style={{ listStyle:'none', padding:0, margin:0, display:'flex', flexDirection:'column', gap:'8px' }}>
              {['Lima, Perú','novastreetwear@gmail.com','Lun–Sáb: 10am – 8pm'].map(t => (
                <li key={t} style={{ color:'#888', fontSize:'0.85rem' }}>{t}</li>
              ))}
            </ul>
          </div>
        </div>
        <div style={{ borderTop:'1px solid #1a1a1a', padding:'20px 0', display:'flex', justifyContent:'space-between', alignItems:'center', flexWrap:'wrap', gap:'10px' }}>
          <span className="bebas" style={{ fontSize:'1rem', letterSpacing:'2px' }}>
            NOVA <span style={{ color:'#e8c84a' }}>STREETWEAR</span>
          </span>
          <p style={{ color:'#888', fontSize:'0.78rem', margin:0 }}>
            &copy; {anio} Nova Streetwear — Todos los derechos reservados.
          </p>
        </div>
      </div>
      <style>{`
        @media (max-width: 768px) {
          .footer-grid { grid-template-columns: 1fr !important; gap: 28px !important; }
        }
      `}</style>
    </footer>
  );
}
