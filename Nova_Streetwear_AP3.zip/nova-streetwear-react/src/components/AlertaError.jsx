export default function AlertaError({ mensaje }) {
  return (
    <div className="alert-error-box" style={{ marginBottom:'20px' }}>
      <strong>⚠ Error:</strong> {mensaje}<br/>
      <span style={{ fontSize:'0.78rem', display:'block', marginTop:'6px' }}>
        Ejecuta: <code style={{ background:'#1a1a1a', padding:'2px 8px', color:'#e8c84a' }}>npx json-server db.json --port 3000</code>
      </span>
    </div>
  );
}
