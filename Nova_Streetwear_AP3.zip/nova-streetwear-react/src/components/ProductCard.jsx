export default function ProductCard({ producto, onAgregar }) {
  const { nombre, imagen, categoria, precio, stock, oferta, descuento } = producto;
  const precioFinal = oferta ? precio * (1 - descuento / 100) : precio;
  const agotado = stock === 0;

  return (
    <div className={`product-card ${oferta ? 'oferta' : ''}`}>
      {/* Imagen */}
      <div style={{ position:'relative', background:'#111', height:'240px', overflow:'hidden' }}>
        <img src={imagen} alt={nombre}
          style={{ width:'100%', height:'100%', objectFit:'cover' }}
          onError={e => { e.target.src='https://placehold.co/400x400/1a1a1a/e8c84a?text=NOVA'; }} />
        {oferta && (
          <span style={{ position:'absolute', top:'10px', left:'10px', background:'#e8c84a', color:'#0a0a0a', fontSize:'0.68rem', fontWeight:800, letterSpacing:'1px', padding:'3px 10px' }}>
            -{descuento}%
          </span>
        )}
        {agotado && (
          <span style={{ position:'absolute', top:'10px', right:'10px', background:'#e05555', color:'#fff', fontSize:'0.68rem', fontWeight:800, padding:'3px 10px' }}>
            AGOTADO
          </span>
        )}
      </div>

      {/* Info */}
      <div style={{ padding:'16px', display:'flex', flexDirection:'column', gap:'8px', flex:1 }}>
        <span style={{ color:'#e8c84a', fontSize:'0.68rem', fontWeight:800, letterSpacing:'2px', textTransform:'uppercase' }}>{categoria}</span>
        <h5 style={{ fontWeight:700, fontSize:'0.85rem', textTransform:'uppercase', letterSpacing:'0.5px', color:'#f5f5f0', margin:0, lineHeight:1.3 }}>{nombre}</h5>

        <div style={{ display:'flex', alignItems:'baseline', gap:'10px', marginTop:'auto' }}>
          {oferta && <span style={{ fontSize:'0.85rem', color:'#555', textDecoration:'line-through' }}>S/ {precio}</span>}
          <span className="bebas" style={{ fontSize:'1.6rem', color:'#e8c84a', letterSpacing:'1px' }}>S/ {precioFinal.toFixed(0)}</span>
        </div>

        <p style={{ fontSize:'0.75rem', color: stock < 5 ? '#e8c84a' : '#666', margin:0 }}>
          Stock: {stock} unidades
        </p>

        <button onClick={() => !agotado && onAgregar && onAgregar(producto)}
          disabled={agotado}
          style={{
            marginTop:'8px', padding:'10px',
            background: agotado ? '#2e2e2e' : '#e8c84a',
            color: agotado ? '#555' : '#0a0a0a',
            fontWeight:800, fontSize:'0.75rem', letterSpacing:'1.5px',
            textTransform:'uppercase', border:'none',
            cursor: agotado ? 'not-allowed' : 'pointer',
            transition:'background .2s',
          }}
          onMouseEnter={e => { if (!agotado) e.target.style.background='#f0d84e'; }}
          onMouseLeave={e => { if (!agotado) e.target.style.background='#e8c84a'; }}>
          {agotado ? 'Agotado' : 'Agregar al carrito'}
        </button>
      </div>
    </div>
  );
}
