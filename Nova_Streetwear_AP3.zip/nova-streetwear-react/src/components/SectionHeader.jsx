export default function SectionHeader({ label, titulo, subtitulo, center = false }) {
  return (
    <div className="fade-in" style={{ marginBottom:'40px', textAlign: center ? 'center' : 'left' }}>
      {label && <span className="section-label">{label}</span>}
      <h2 className="section-title bebas">{titulo}</h2>
      {subtitulo && <p style={{ color:'#888', fontSize:'0.9rem', marginTop:'12px', lineHeight:1.7, maxWidth:'520px' }}>{subtitulo}</p>}
    </div>
  );
}
